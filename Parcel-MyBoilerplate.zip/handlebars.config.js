module.exports = {
    layouts: 'src/layouts',
    partials: 'src/partials',
};