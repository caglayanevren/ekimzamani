## bootstrap.js v4.4.1 for  jquery 3.5.0

### in node_modules/bootsrap/dist/js/bootstrap.js line 1509 change

# if (!data && _config.toggle && /show|hide/.test(config))

### to

# if (!data && _config.toggle && /show|hide/.test(_config))